﻿using System;
using System.Collections.Generic;

namespace GameBase
{
    /// <summary>
    /// Defines the basic properties required for
    /// a message to be sent through the messenger
    /// </summary>
	public interface IMessage
	{
        /// <summary>
        /// Enumeration for the message type. We use strings so they can
        /// be any value.
        /// </summary>
        int Type { get; set; }

        /// <summary>
        /// Sender of the message
        /// </summary>
        object Sender { get; set; }

        /// <summary>
        /// Receiver of the message
        /// </summary>
        int  Recipient { get; set; }

        /// <summary>
        /// Time in seconds to delay the processing of the message
        /// </summary>
        float Delay { get; set; }

        /// <summary>
        /// Core data of the message
        /// </summary>
        object Data { get; set; }

        /// <summary>
        /// Determines if the message was sent
        /// </summary>
        Boolean IsSent { get; set; }

        /// <summary>
        /// Determines if the message was handled
        /// </summary>
        Boolean IsHandled { get; set; }
		
		/// <summary>
		/// Clear this instance.
		/// </summary>
		void Clear();
    }
}
