using UnityEngine;

namespace GameBase
{
    public class StringContentHolder : ScriptableObject
    {
        public string[] content;
    }
}