﻿using System.Collections.Generic;
using UnityEngine;

namespace GameBase
{
    public class UILabelData : MonoBehaviour
    {
        public UILabel label;
        public int index;
    }
}
