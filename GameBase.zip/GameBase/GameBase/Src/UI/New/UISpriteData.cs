﻿using System.Collections.Generic;
using UnityEngine;

namespace GameBase
{
    public class UISpriteData : MonoBehaviour
    {
        public UISprite sprite;
        public int index;
    }
}
