﻿using System.Collections.Generic;
using UnityEngine;

namespace GameBase
{
    public class UITextureData : MonoBehaviour
    {
        public UITexture texture;
        public int id;
    }
}
