﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace GameBase
{
    public class UIToggleData : MonoBehaviour
    {
        public UIToggle toggle;
        public int originGroup;
    }
}
