﻿
using System;
using System.Collections.Generic;
using System.IO;

namespace GameBase
{
    public class CombineFile
    {
        private string name;
        private Data.combinefiles _combinefiles = null;
        private Dictionary<string, Data.groupcombine> fileDic = null;
        private bool _initHeader = false;

        private int dataOffset = -1;

        private IResourceFileStream fileStream = null;


        public CombineFile(string name)
        {
            this.name = name;
        }

        private void InitHeader()
        {
            if (_initHeader)
                return;
            _initHeader = true;

            IResourceFileStream irs = ResLoader.LoadFileStreamByName(name);
            if (irs == null)
            {
                if (Config.Debug_Log())
                    Debugger.LogError("ERROR: ivnalid combine file name->" + name);
                return;
            }
            byte[] dataArr = new byte[4];
            irs.Read(dataArr, 0, 4);

            MemoryStream ms = new MemoryStream(dataArr);
            BinaryReader br = new BinaryReader(ms);
            int headlen = br.ReadInt32();
            dataOffset = 4 + headlen;

            dataArr = new byte[headlen];
            irs.Read(dataArr, 4, headlen);
            irs.Close();

            ms = new MemoryStream(dataArr);
            _combinefiles = (Data.combinefiles)GameUtils.dataSerializer.Deserialize(ms, null, typeof(Data.combinefiles));

            if (_combinefiles != null)
            {
                fileDic = new Dictionary<string, Data.groupcombine>();
                for (int i = 0, count = _combinefiles.files.Count; i < count; i++)
                {
                    fileDic.Add(_combinefiles.files[i].value, _combinefiles.groups[i]);
                }

                _combinefiles.files.Clear();
                _combinefiles.groups.Clear();
            }
        }

        public void CollectAllFilePath(List<string> lst)
        {
            if (fileDic == null)
                InitHeader();
            if (_combinefiles != null)
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                for (int i = 0, count = _combinefiles.files.Count; i < count; i++)
                {
                    Data.groupcombine gc = _combinefiles.groups[i];
                    for (int j = 0, jcount = gc.infos.Count; j < jcount; j++)
                    {
                        Data.combineinfo info = gc.infos[j];
                        sb.Append(_combinefiles.dirs[info.dir]);
                        sb.Append(_combinefiles.files[i]);

                        lst.Add(sb.ToString());
                    }
                }
            }
        }

        public void Reset()
        {
            Close();
            fileDic = null;
            _initHeader = false;
            _combinefiles = null;
        }

        private Data.combineinfo GetCombineInfo(string path)
        {
            if (fileDic == null)
                InitHeader();
            if (fileDic == null)
                return null;
            string fileName = Path.GetFileName(path);
            Data.groupcombine group;
            if (!fileDic.TryGetValue(fileName, out group))
            {
                return null;
            }

            Data.combineinfo info = null;
            if (group.infos.Count > 1)
            {
                string filePath = GetDirectoryPath(path);
                Data.combineinfo ci = null;
                string dir = null;
                float simlarValue = -1;
                float tempSimlarValue;
                for (int i = 0, count = group.infos.Count; i < count; i++)
                {
                    ci = group.infos[i];
                    if (ci.dir < 0 || ci.dir >= _combinefiles.dirs.Count)
                        continue;

                    dir = _combinefiles.dirs[ci.dir].value;
                    if (IsSimilarPath(dir, filePath, out tempSimlarValue))
                    {
                        if (tempSimlarValue > simlarValue)
                        {
                            info = ci;
                            simlarValue = tempSimlarValue;
                        }
                        else if (simlarValue != 0 && tempSimlarValue == simlarValue)
                        {
                            if (info != null)
                            {
                                Debugger.LogError("asset error: check is simplar path has same simlar value->" + _combinefiles.dirs[info.dir].value + "^" + dir + "^" + filePath + "^" + fileName + "^" + path);
                                Debugger.LogError("------simlar path count->" + group.infos.Count);
                                for (int j = 0, jcount = group.infos.Count; j < jcount; j++)
                                {
                                    ci = group.infos[j];
                                    if (ci.dir < 0 || ci.dir >= _combinefiles.dirs.Count)
                                        continue;
                                    Debugger.LogError("------simlar path->" + j + "^" + _combinefiles.dirs[ci.dir].value);
                                }
                            }
                            else
                                Debugger.LogError("asset error: check is simplar path has same simlar value info is null->" + dir + "^" + filePath + "^" + fileName + "^" + path);
                        }
                    }
                }
            }
            else if (group.infos.Count == 1)
            {
                info = group.infos[0];
            }

            if (info == null)
            {
                if (UnityEngine.Application.platform == UnityEngine.RuntimePlatform.WindowsEditor)
                {
                    Data.groupcombine gcf;
                    if (fileDic.TryGetValue(fileName, out gcf))
                    {
                        string str = null;
                        for (int i = 0, count = gcf.infos.Count; i < count; i++)
                        {
                            str += _combinefiles.dirs[gcf.infos[i].dir].value + "^";
                        }

                        UnityEngine.Debug.LogError("combine exception file->" + path + "^" + fileName + ": " + str);
                    }
                }
                return null;
            }

            return info;
        }

        private int GetRealOffset(Data.combineinfo info)
        {
            return dataOffset + info.start;
        }

        public void GetFileDetail(string path, out int offset, out int size, out bool encrypt)
        {
            offset = -1;
            size = 0;
            encrypt = false;
            Data.combineinfo info = GetCombineInfo(path);
            if (info == null)
                return;

            offset = GetRealOffset(info);
            size = info.size;
            encrypt = info.encrypt;
        }

        private bool IsSimilarPath(string origin, string dest, out float simlarValue)
        {
            string p1 = origin;
            string p2 = dest;
            simlarValue = 0;
            if (p1 == null || p2 == null)
                return false;
            if (p1.Length == 0 && p2.Length == 0)
                return true;

            if (p1.Length == 0 || p2.Length == 0)
            {
                return false;
            }

            string longStr = null;
            string shortStr = null;
            if (p1.Length > p2.Length)
            {
                longStr = p1;
                shortStr = p2;
            }
            else
            {
                longStr = p2;
                shortStr = p1;
            }

            char sc, lc;
            char vsc = '♪';
            int vscIndex = 0;
            for (int i = 0, count = shortStr.Length; i < count; i++)
            {
                sc = shortStr[i];
                if (sc == '.' || sc == '/' || sc == '\\')
                    continue;
                vsc = sc;
                vscIndex = i;
                break;
            }

            int longStrLen = longStr.Length;
            int shortStrLen = shortStr.Length;
            int num = 0;
            for (int i = shortStrLen - 1; i >= vscIndex; i--)
            {
                sc = shortStr[i];
                lc = longStr[longStrLen - 1 - (shortStrLen - 1 - i)];
                if (sc != lc)
                {
                    if ((sc == '/' || sc == '\\') && (lc == '/' || lc == '\\'))
                        continue;
                    return false;
                }

                num++;
            }

            simlarValue = (float)num / dest.Length;
            simlarValue += (float)shortStr.Length / longStr.Length * 100;

            return true;
        }

        public bool Open()
        {
            if (fileStream != null)
                return true;
            fileStream = ResLoader.LoadFileStreamByName(name);
            return fileStream != null;
        }

        public void Close()
        {
            if (fileStream != null)
            {
                fileStream.Close();
                fileStream = null;
            }
        }

        private string GetDirectoryPath(string path)
        {
            if (path == null)
                return null;

            int index = 0;
            char sc = '♪';
            for (int i = path.Length - 1; i >= 0; i--)
            {
                sc = path[i];
                if (sc == '/' || sc == '\\')
                {
                    index = i;
                    break;
                }
            }

            if (index > 0)
                return path.Substring(0, index);
            else
                return "";
        }

        public byte[] Read(string path)
        {
            Data.combineinfo info = GetCombineInfo(path);
            if (info == null)
                return null;

            if (info.size <= 0)
                return null;

            if (fileStream != null)
            {
                byte[] data = new byte[info.size];
                int offset = GetRealOffset(info);
                fileStream.Read(data, offset, info.size);
                if (info.encrypt)
                    ResLoader.RemoveImpurity(data, null, false);

                return data;
            }
            else
            {
                IResourceFileStream fs = ResLoader.LoadFileStreamByName(name);
                if (fs == null)
                    return null;

                byte[] data = new byte[info.size];
                int offset = GetRealOffset(info);
                fs.Read(data, offset, info.size);
                if (info.encrypt)
                    ResLoader.RemoveImpurity(data, null, false);

                return data;
            }
        }
    }
}
