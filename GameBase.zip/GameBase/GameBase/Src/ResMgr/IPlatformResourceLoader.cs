﻿using System.Collections.Generic;
using System.Collections;
using UnityEngine;

using static GameBase.ResourceLoader;

namespace GameBase
{
    public interface IPlatformResourceLoader
    {
        byte[] SyncReadBytes(string path);
        int SyncReadBytes(string path, int begin, int length, byte[] destBuf);

        IResourceFileStream LoadFile(string path);

        void LoadBundle(string originName, string destName, string path, Data.VersionFile.Type fileType, EndLoadBundle endLoad, System.Object obj, bool assetBundle = false);//, bool cb_whatever = false);
    }
}
