// Copyright (c) 2014 Jonathan Magnan (http://jonathanmagnan.com)
// All rights reserved (http://jonathanmagnan.com/extension-methods-library/).
// Licensed under MIT License (MIT)

using System;

public static partial class ObjectExtension
{
    public static uint? ToNullableUInt32OrDefault(this object @this)
    {
        try
        {
            if (@this == null || @this == DBNull.Value)
            {
                return null;
            }

            return Convert.ToUInt32(@this);
        }
        catch (Exception)
        {
            return default(uint);
        }
    }

    public static uint? ToNullableUInt32OrDefault(this object @this, uint? defaultValue)
    {
        try
        {
            if (@this == null || @this == DBNull.Value)
            {
                return null;
            }

            return Convert.ToUInt32(@this);
        }
        catch (Exception)
        {
            return defaultValue;
        }
    }

    public static uint? ToNullableUInt32OrDefault(this object @this, Func<uint?> defaultValueFactory)
    {
        try
        {
            if (@this == null || @this == DBNull.Value)
            {
                return null;
            }

            return Convert.ToUInt32(@this);
        }
        catch (Exception)
        {
            return defaultValueFactory();
        }
    }
}