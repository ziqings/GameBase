// Copyright (c) 2014 Jonathan Magnan (http://jonathanmagnan.com)
// All rights reserved (http://jonathanmagnan.com/extension-methods-library/).
// Licensed under MIT License (MIT)

using System;

public static partial class ObjectExtension
{
    public static ulong? ToNullableULongOrDefault(this object @this)
    {
        try
        {
            if (@this == null || @this == DBNull.Value)
            {
                return null;
            }

            return Convert.ToUInt64(@this);
        }
        catch (Exception)
        {
            return default(ulong);
        }
    }

    public static ulong? ToNullableULongOrDefault(this object @this, ulong? defaultValue)
    {
        try
        {
            if (@this == null || @this == DBNull.Value)
            {
                return null;
            }

            return Convert.ToUInt64(@this);
        }
        catch (Exception)
        {
            return defaultValue;
        }
    }

    public static ulong? ToNullableULongOrDefault(this object @this, Func<ulong?> defaultValueFactory)
    {
        try
        {
            if (@this == null || @this == DBNull.Value)
            {
                return null;
            }

            return Convert.ToUInt64(@this);
        }
        catch (Exception)
        {
            return defaultValueFactory();
        }
    }
}