// Copyright (c) 2014 Jonathan Magnan (http://jonathanmagnan.com)
// All rights reserved (http://jonathanmagnan.com/extension-methods-library/).
// Licensed under MIT License (MIT)

using System;

public static partial class CharExtension
{
    /// <summary>
    ///     Indicates whether the specified Unicode character is categorized as a symbol character.
    /// </summary>
    /// <param name="c">The Unicode character to evaluate.</param>
    /// <returns>true if  is a symbol character; otherwise, false.</returns>
    public static Boolean IsSymbol(this Char c)
    {
        return Char.IsSymbol(c);
    }
}